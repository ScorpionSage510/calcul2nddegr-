import tkinter as tk

def enregistrer_donnees():
    a = entry_a.get()
    b = entry_b.get()
    c = entry_c.get()

    with open("historique.txt", "a") as fichier:
        fichier.write(f"a={a}, b={b}, c={c}\n")

    # Efface les champs de saisie après l'enregistrement
    entry_a.delete(0, tk.END)
    entry_b.delete(0, tk.END)
    entry_c.delete(0, tk.END)

root = tk.Tk()
root.title("Enregistrement dans l'historique")

frame = tk.Frame(root)
frame.pack(padx=20, pady=20)

label_a = tk.Label(frame, text="Valeur de a :")
label_a.grid(row=0, column=0)
entry_a = tk.Entry(frame)
entry_a.grid(row=0, column=1)

label_b = tk.Label(frame, text="Valeur de b :")
label_b.grid(row=1, column=0)
entry_b = tk.Entry(frame)
entry_b.grid(row=1, column=1)

label_c = tk.Label(frame, text="Valeur de c :")
label_c.grid(row=2, column=0)
entry_c = tk.Entry(frame)
entry_c.grid(row=2, column=1)

bouton_enregistrer = tk.Button(root, text="Enregistrer", command=enregistrer_donnees)
bouton_enregistrer.pack()

root.mainloop()
